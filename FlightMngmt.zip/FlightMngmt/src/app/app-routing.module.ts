import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddflightComponent } from './addflight/addflight.component';
import {UpdateflightComponent} from './updateflight/updateflight.component';
import {DeleteflightComponent} from './deleteflight/deleteflight.component';
import{ViewallflightComponent} from './viewallflight/viewallflight.component';
import { HomeFlightserviceComponent } from './home-flightservice/home-flightservice.component';

const routes: Routes = [
  {path:'',redirectTo:'home',pathMatch: 'full'},
  {path: 'home',component:HomeFlightserviceComponent},
  {path:'addflight', component:AddflightComponent},
  {path:'updateflight', component:UpdateflightComponent},
  {path:'deleteflight', component:DeleteflightComponent},
  {path:'viewallflight', component:ViewallflightComponent},
 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

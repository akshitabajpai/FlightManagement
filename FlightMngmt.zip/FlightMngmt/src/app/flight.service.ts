import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Flight } from './flight'

@Injectable({
  providedIn: 'root'
})
export class FlightService {

  constructor(private http:HttpClient) { }
  
  public viewAllflight():Observable<any>{
    console.log("Am inside service");
    return this.http.get("http://localhost:7077/viewallflight");
  }
  public addFlight(flight:Flight):Observable<any>{
    return this.http.post("http://localhost:7077/addflight",flight,{responseType:'text'});
  }
  public deleteFlight(flightNumber:number):Observable<any>{
    return this.http.delete(`http://localhost:7077/deleteflight/${flightNumber}`,{responseType:'text'});
  }
  public updateFlight(flight:Flight):Observable<any>{
    return this.http.put(`http://localhost:7077/updateflight/${flight.flightNumber}`,flight,{responseType:'text'});
  }
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-flightservice',
  templateUrl: './home-flightservice.component.html',
  styleUrls: ['./home-flightservice.component.css']
})
export class HomeFlightserviceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

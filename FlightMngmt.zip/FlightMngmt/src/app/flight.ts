export class Flight {
    flightNumber:number;
    flightModel:string;
    carrierName:string;
    seatCapacity:number;
}

import { Component, OnInit } from '@angular/core';
import { Flight } from '../flight';
import { FlightService } from '../flight.service';

@Component({
  selector: 'app-deleteflight',
  templateUrl: './deleteflight.component.html',
  styleUrls: ['./deleteflight.component.css']
})
export class DeleteflightComponent implements OnInit {

  flightNumber:number = 0;
  msg:String;
  errorMsg:String;
  constructor(private flightService:FlightService) { }

  ngOnInit(): void {
  }
  deleteFlight(){
    console.log(this.flightNumber);
    this.flightService.deleteFlight(this.flightNumber).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      },
      error => {
        alert("Invalid flight number");        
      });
  }


}

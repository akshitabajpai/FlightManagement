import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeFlightserviceComponent } from './home-flightservice.component';

describe('HomeFlightserviceComponent', () => {
  let component: HomeFlightserviceComponent;
  let fixture: ComponentFixture<HomeFlightserviceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomeFlightserviceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeFlightserviceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

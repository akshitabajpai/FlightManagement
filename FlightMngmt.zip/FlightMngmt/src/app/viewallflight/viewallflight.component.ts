import { Component, OnInit } from '@angular/core';
import { Flight } from '../flight';
import { FlightService } from '../flight.service';

@Component({
  selector: 'app-viewallflight',
  templateUrl: './viewallflight.component.html',
  styleUrls: ['./viewallflight.component.css']
})
export class ViewallflightComponent implements OnInit {

  flights:Flight[]=[];
  constructor(private flightService:FlightService) { }
 

  ngOnInit(): void {
    console.log("Am inside view component");
    this.flightService.viewAllflight().subscribe(data=>this.flights=data);
    console.log(this.flights);
  }

}

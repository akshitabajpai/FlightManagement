import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AddflightComponent } from './addflight/addflight.component';
import { DeleteflightComponent } from './deleteflight/deleteflight.component';
import { ViewallflightComponent } from './viewallflight/viewallflight.component';
import { UpdateflightComponent } from './updateflight/updateflight.component';
import { HomeFlightserviceComponent } from './home-flightservice/home-flightservice.component';

@NgModule({
  declarations: [
    AppComponent,
    AddflightComponent,
    DeleteflightComponent,
    ViewallflightComponent,
    UpdateflightComponent,
    HomeFlightserviceComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
